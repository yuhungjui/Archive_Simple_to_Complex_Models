!
! Copyright (C) 1991-2003  ; All Rights Reserved ; Colorado State University
! Colorado State University Research Foundation ; ATMET, LLC
! 
! This file is free software; you can redistribute it and/or modify it under the
! terms of the GNU General Public License as published by the Free Software 
! Foundation; either version 2 of the License, or (at your option) any later version.
! 
! This software is distributed in the hope that it will be useful, but WITHOUT ANY 
! WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
! PARTICULAR PURPOSE.  See the GNU General Public License for more details.
!
! You should have received a copy of the GNU General Public License along with this 
! program; if not, write to the Free Software Foundation, Inc., 
! 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
!======================================================================================
!f90
!############################# Change Log ##################################
! 4.3.0.0
!
!###########################################################################

!---------------------------------------------------------------------------
!     Common block include file for the   R A M S   model - bin microphysics
!---------------------------------------------------------------------------
!
! For stratocumulus simulations use NB,LPX=25,
! For convective simulations use NB,LPX=34 (inc. L&L binary breakup)
! NS is the number of the first vector that contains "bins information"
! The first vector is for saturation excess
! The second vector is for saturation excess with respect to ice in LEVEL>4
! The next vector is for CCN concentration
! The next vector is for IN already activated LEVEL>4
! The next vector is for IN already activated thru contact LEVEL>4
!
!  LN2 is the number of bins for CCN when using Yan's nucleation
!
!parameter :: NB=25,LPX=25,LPA=25,LCO=19,LPA1=LPA+1,NSH=6
integer, parameter :: MB=36,LB=MB,LRK=15,LCO=19,LN2=67
!parameter :: MB=36,LB=36,LRK=15,LCO=19,LN2=67
integer, parameter :: NSDSW=1,NSDSI=2,NSCCN=3,NSIN=4,NSIC=5,NSH=6
integer, parameter :: LK2=6,LKI=34

