!
! Copyright (C) 1991-2003  ; All Rights Reserved ; Colorado State University
! Colorado State University Research Foundation ; ATMET, LLC
! 
! This file is free software; you can redistribute it and/or modify it under the
! terms of the GNU General Public License as published by the Free Software 
! Foundation; either version 2 of the License, or (at your option) any later version.
! 
! This software is distributed in the hope that it will be useful, but WITHOUT ANY 
! WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
! PARTICULAR PURPOSE.  See the GNU General Public License for more details.
!
! You should have received a copy of the GNU General Public License along with this 
! program; if not, write to the Free Software Foundation, Inc., 
! 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
!======================================================================================
!f90
!############################# Change Log ##################################
! 4.3.0.1
!
! 000828 MJB none ##
!            Added new interface declarations for new C routines. ##
!
!###########################################################################

INTERFACE


function iralloc (mem,a,ioff)
  !DEC$ ATTRIBUTES C,ALIAS:'_iralloc' :: iralloc
  !DEC$ ATTRIBUTES REFERENCE:: mem,ioff,a
  real*4 a(*)
  integer*4 mem,ioff
end function iralloc

function irfree (mem)
  !DEC$ ATTRIBUTES C,ALIAS:'_irfree' :: irfree
  !DEC$ ATTRIBUTES REFERENCE:: mem
  integer*4 mem
end function irfree

integer function irsleep (isec)
  !DEC$ ATTRIBUTES C,ALIAS:'_irsleep' :: irsleep
  integer*4 isec 
end

subroutine rams_c_close ()
  !DEC$ ATTRIBUTES C,ALIAS:'_rams_c_close' :: rams_c_close
end

integer function v5dclose ()
  !DEC$ ATTRIBUTES C,ALIAS:'_v5dclose' :: v5dclose
end

integer function v5dsetunits (n,varunits)
  !DEC$ ATTRIBUTES C,ALIAS:'_v5dsetunits' :: v5dsetunits
  character *(*) varunits [reference]
  integer n [reference]
end

integer function v5dwrite (n1,n2,arr)
  !DEC$ ATTRIBUTES C,ALIAS:'_v5dwrite' :: v5dwrite
  real arr(*)
  integer n1 [reference], n2 [reference]
end

integer function v5dcreate (flnm,ntt,nvv,njj,nii,nl  &
            ,varname,fltimes,fldates,compressmode  &
            ,projection,proj_args,vertical,vert_args)
  !DEC$ ATTRIBUTES C,ALIAS:'_v5dcreate' :: v5dcreate
  character*(*) flnm [reference]
  character*(*) varname(*)
  integer ntt [reference], nvv [reference], nl(*)
  integer njj [reference], nii [reference]
  integer projection [reference], compressmode [reference]
  integer fltimes(*), fldates(*)
  real proj_args(*), vert_args(*)
  integer vertical [reference]

end

subroutine rams_c_open(filename,faccess)
  !DEC$ ATTRIBUTES C,ALIAS:'_rams_c_open' :: rams_c_open
  character *(*) filename [reference]
  character *(*) faccess [reference]
end

subroutine rams_c_read(ioff,nbytes,buff)
  !DEC$ ATTRIBUTES C,ALIAS:'_rams_c_read' :: rams_c_read
  integer ioff [reference], nbytes [reference]
  real buff(*)
end

subroutine rams_c_read_char(ioff,nbytes,buff)
   !DEC$ ATTRIBUTES C,ALIAS:'_rams_c_read_char' :: rams_c_read_char
   integer ioff [reference], nbytes [reference]
   character*(*) buff(*) 
end

subroutine vforecr (unit,a,n,nbits,scr,cscr,type,irec)
  !DEC$ ATTRIBUTES C,ALIAS:'_vforecr' :: vforecr
  integer unit[reference], n[reference]
  integer nbits[reference], irec [reference]
  character*(*)  type [reference]
  real a[reference], scr[reference], cscr [reference]
end

subroutine vfirecr (unit,a,n,type,scr,irec)
  !DEC$ ATTRIBUTES C,ALIAS:'_vfirecr' :: vfirecr
  integer unit[reference], n[reference]
  integer irec [reference]
  character*(*)  type [reference]
  real a(n)
  real scr(n)
end

subroutine par_init_put (f1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_init_put' :: par_init_put
  integer i2 [reference]
  real f1(*)
end

subroutine par_send (i1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_send' :: par_send
  integer i1[reference],i2 [reference]
end

subroutine par_put_int (i1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_put_int' :: par_put_int
  integer i1(*),i2 [reference]
end

subroutine par_put_chr (c1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_put_chr' :: par_put_chr
  integer i2 [reference]
  character c1 (*)
end

subroutine par_put_float (f1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_put_float' :: par_put_float
  integer i2 [reference]
  real f1(*)
end

subroutine par_send_noblock (i1,i2,i3)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_send_noblock' :: par_send_noblock
  integer i1[reference],i2 [reference],i3 [reference]
end

subroutine par_get_noblock (v1,i1,i2,i3,i4)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_get_noblock' :: par_get_noblock
  integer i1[reference],i2 [reference],i3 [reference]
  integer i4 [reference]
  real v1(*)
end

subroutine par_assoc_buff (v1,i1)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_assoc_buff' :: par_assoc_buff
  integer i1[reference]
  real v1(*)
end

subroutine par_wait (i1,i2,i3,i4)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_wait' :: par_wait
  integer i1[reference],i2 [reference],i3 [reference]
  integer i4 [reference]
end

subroutine par_get_new (v1,i1,i2,i3,i4,i5)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_get_new' :: par_get_new
  integer i1[reference],i2 [reference],i3 [reference]
  integer i4 [reference],i5 [reference]
  real v1(*)
end

subroutine par_get_int (i1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_get_int' :: par_get_int
  integer i1(*),i2 [reference]
end

subroutine par_get_float (f1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_get_float' :: par_get_float
  integer i2 [reference]
  real f1(*)
end

subroutine par_get_chr (c1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_get_chr' :: par_get_chr
  integer i2 [reference]
  character c1 (*)
end

subroutine par_exit ()
  !DEC$ ATTRIBUTES C,ALIAS:'_par_exit' :: par_exit
end

subroutine par_ready (i1,i2,i3)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_ready' :: par_ready
  integer i1 [reference],i2(*),i3 [reference]
end

subroutine par_pause (i1,i2)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_pause' :: par_pause
  integer i1 [reference],i2 [reference]
end

subroutine par_init_fortran (argc,fargv,farglen,machnum,machsize)
  !DEC$ ATTRIBUTES C,ALIAS:'_par_init_fortran' :: par_init_fortran
  integer argc [reference], farglen [reference]
  character fargv(*)
  integer machnum [reference], machsize [reference]
end

function readdted1 (i1, a)
  !DEC$ ATTRIBUTES C,ALIAS:'_readdted1' :: readdted1
  integer i1
  real :: a(*)
end


END INTERFACE
