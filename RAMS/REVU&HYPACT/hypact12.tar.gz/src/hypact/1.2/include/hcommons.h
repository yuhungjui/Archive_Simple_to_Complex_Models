!f90
!
! Copyright (C) 1991-2003  ; All Rights Reserved ; ATMET, LLC
! 
! This file is free software; you can redistribute it and/or modify it under the
! terms of the GNU General Public License as published by the Free Software 
! Foundation; either version 2 of the License, or (at your option) any later version.
! 
! This software is distributed in the hope that it will be useful, but WITHOUT ANY 
! WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
! PARTICULAR PURPOSE.  See the GNU General Public License for more details.
!
! You should have received a copy of the GNU General Public License along with this 
! program; if not, write to the Free Software Foundation, Inc., 
! 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
!======================================================================================

!---------------------------------------------------------------------------
!     HYPACT commons
!---------------------------------------------------------------------------

! grid and met variables
!---------------------------------------------------------------------------
integer, parameter :: nvar3d=19,nvar2d=35,nvarsd=0
integer, parameter :: maxg=10,maxi=150,maxj=150,maxk=100
integer, parameter :: maxhi=400,maxhj=400,maxhk=100
integer, parameter :: maxfiles=200
!---------------------------------------------------------------------------
integer, dimension(maxg) :: iscr1h,iscr2h,iscr3h,iuph,ivph,iwph,itkeph  &
                           ,isiguh,isigvh,isigwh,ids2h,itluh,itlvh,itlwh  &
                           ,itheth,ikhvh,ikhhh,ipresh,itemph
common/memindex3/iscr1h,iscr2h,iscr3h,iuph,ivph,iwph,itkeph  &
                ,isiguh,isigvh,isigwh,ids2h,itluh,itlvh,itlwh  &
                ,itheth,ikhvh,ikhhh,ipresh,itemph
!---------------------------------------------------------------------------
integer, dimension(maxg) :: itgph,islmstph,itsph,islmssph
common/memindexs/itgph,islmstph,itsph,islmssph
!---------------------------------------------------------------------------
integer, dimension(maxg) :: idxuh,idxvh,idxth,idxmh,idyuh,idyvh,idyth  &
                           ,idymh,ifmapuh,ifmapvh,ifmapth,ifmapmh,ifmapuih  &
                           ,ifmapvih,ifmaptih,ifmapmih,ipctlh,itopth,itopuh  &
                           ,itopvh,itopmh,irtgth,irtguh,irtgvh,irtgmh  &
                           ,if13uh,if13vh,if13th,if13mh,if23uh,if23vh  &
                           ,if23th,if23mh,iglath,iglonh
common/memindex2/idxuh,idxvh,idxth,idxmh,idyuh,idyvh,idyth  &
                ,idymh,ifmapuh,ifmapvh,ifmapth,ifmapmh,ifmapuih  &
                ,ifmapvih,ifmaptih,ifmapmih,ipctlh,itopth,itopuh  &
                ,itopvh,itopmh,irtgth,irtguh,irtgvh,irtgmh  &
                ,if13uh,if13vh,if13th,if13mh,if23uh,if23vh  &
                ,if23th,if23mh,iglath,iglonh
!---------------------------------------------------------------------------
integer                       :: ngrh
integer, dimension(maxg)      :: nnxh,nnyh,nnzh,nngh
integer, dimension(maxk,maxg) :: nrzh,kpmh
integer, dimension(maxi,maxg) :: ipmh
integer, dimension(maxj,maxg) :: jpmh
real                          :: pslat,pslon
real, dimension(maxg)         :: delxh,delyh,delzh
real, dimension(maxi,maxg)    :: xmh,xth
real, dimension(maxj,maxg)    :: ymh,yth
real, dimension(maxk,maxg)    :: zmh,zth,dzmh,dzth,hth,hwh
common/gspace/ngrh,nnxh,nnyh,nnzh,nngh,xmh,xth,ymh,yth,zmh,zth,dzmh,dzth  &
             ,delxh,delyh,delzh,hth,hwh,pslat,pslon,nrzh,kpmh,ipmh,jpmh
!---------------------------------------------------------------------------
real, dimension(maxi,maxg) :: ei1h,ei2h,ei3h
real, dimension(maxj,maxg) :: ej1h,ej2h,ej3h
real, dimension(maxk,maxg) :: ek1h,ek2h,ek3h
common/hnest/  ei1h,ei2h,ei3h,ej1h,ej2h,ej3h,ek1h,ek2h,ek3h
!---------------------------------------------------------------------------
integer                     :: ipctlhg,nih,njh,nkh,img,irkt  &
                              ,irim,irjm,irkm,irktg,irimg,irjmg,irkmg  &
                              ,itopthg
integer, dimension(maxg)    :: ie1,in1,iu1,ie1n1,ie1u1,in1u1,ie1n1u1  &
                              ,ie12d,in12d,ie1n12d,in,jn,kn
real                        :: ztoph
real, dimension(maxhi)      :: xh,bizon,dxh,dxhi
real, dimension(maxhj)      :: yh,bjzon,dyh,dyhi
real, dimension(maxhk)      :: zh,dzh,dzhi
real, dimension(maxhi,maxg) :: drim
real, dimension(maxhj,maxg) :: drjm
real, dimension(maxhk,maxg) :: drkm
common/hgrd/in,jn,kn,xh,yh,zh,bizon,bjzon,dxh,dyh,dzh,dxhi,dyhi,dzhi  &
           ,ie1,in1,iu1,ie1n1,ie1u1,in1u1,ie1n1u1,ie12d,in12d,ie1n12d  &
           ,ipctlhg,nih,njh,nkh,img,irkt,irim,irjm,irkm,irktg  &
           ,irimg,irjmg,irkmg,itopthg,ztoph,drim,drjm,drkm
!---------------------------------------------------------------------------

! general namelist variables
!---------------------------------------------------------------------------
integer, parameter :: maxspec=50,maxsrc=100,polypts=10,maxem=300
!---------------------------------------------------------------------------
character(len=80) :: metpref,hyppref,histpref,histfile
common/gen_chars/metpref,hyppref,histpref,histfile
!---------------------------------------------------------------------------
integer :: ihyprun,maxpart,npartbl,ihturb,iadvord,ihybpart,ihybmin,ihgrid  &
          ,izeromet,iwarn
real    :: dtpart,freqavg,hybfreq,hybhoriz,hybvert,hgridtop
common/general/ihyprun,dtpart,maxpart,npartbl,freqavg,ihturb,iadvord  &
              ,hybfreq,ihybpart,ihybmin,hybhoriz,hybvert,ihgrid,hgridtop  &
              ,izeromet,iwarn
!---------------------------------------------------------------------------
integer :: ipartout,ieulout,ilagout,imetout,ioutfmt,irgrid,ilagprob
real    :: hypfreq,histfreq,avgtime
common/houtput/hypfreq,histfreq,ipartout,ieulout,ilagout,imetout,avgtime  &
             ,ioutfmt,irgrid,ilagprob
!---------------------------------------------------------------------------

! database namelist variables
!---------------------------------------------------------------------------
character(len=80) :: gridfile_db(maxsrc),srcfile,specfile,emfile
character(len=30) :: srcname_db(maxsrc),specname_db(maxspec),units_db(maxspec)
character(len=10) :: shape_db(maxsrc),type_db(maxem),scaling_db(maxem)
common/chars_db/specname_db,units_db,srcname_db,shape_db,gridfile_db  &
               ,type_db,scaling_db,srcfile,specfile,emfile
!---------------------------------------------------------------------------
integer                    :: nspecies_db
integer, dimension(maxsrc) :: ihfall_db,ioutspec_db
real, dimension(maxsrc)    :: wgtmol_db,szpwr_db,szmin_db,szmax_db
common/spec_db/nspecies_db,wgtmol_db,ihfall_db,szpwr_db,szmin_db,szmax_db  &
              ,ioutspec_db
!---------------------------------------------------------------------------
integer                         :: nsources_db
real, dimension(maxsrc)         :: srcx_db,srcy_db,srcz_db,xsize_db  &
                                  ,ysize_db,zsize_db,rotation_db
real, dimension(polypts,maxsrc) :: polylat_db,polylon_db
common/src_db/nsources_db,polylat_db,polylon_db,srcx_db,srcy_db,srcz_db  &
             ,xsize_db,ysize_db,zsize_db,rotation_db
!---------------------------------------------------------------------------
integer                   :: nemissions_db
integer, dimension(maxem) :: iemit_db,isource_db,ispecies_db,irelstrt_db  &
                            ,istrtdays_db,ireldur_db,idurdays_db,numparts_db
real, dimension(maxem)    :: rate_db,ratio_db
common/em_db/nemissions_db,iemit_db,isource_db,ispecies_db,irelstrt_db  &
            ,istrtdays_db,ireldur_db,idurdays_db,numparts_db,rate_db,ratio_db
!---------------------------------------------------------------------------

! model variables
!---------------------------------------------------------------------------
integer, parameter :: maxent=1009,nscratch=11
integer, parameter :: maxatp=9,maxlatp=2,maxcatp=1,maxlcatp=2
!---------------------------------------------------------------------------
character(len=80) :: gridfile(maxsrc)
character(len=30) :: srcname(maxem),specname(maxspec),units(maxspec)
character(len=10) :: sshape(maxem),type(maxem),scaling(maxem)
common/chars/srcname,specname,units,type,scaling,sshape,gridfile
!---------------------------------------------------------------------------
integer                   :: nspecies
integer, dimension(maxem) :: species,ihfall,ioutspec
real, dimension(maxem)    :: wgtmol,szpwr,szmin,szmax
common/spec/nspecies,species,wgtmol,ihfall,szpwr,szmin,szmax,ioutspec
!---------------------------------------------------------------------------
integer                        :: nsources
integer, dimension(maxem)      :: psource
real, dimension(maxem)         :: srcy,ysize,srcz,srcx,xsize,zsize,rotation
real, dimension(polypts,maxem) :: polylat,polylon
common/src/nsources,psource,polylat,polylon,srcy,ysize,srcz,srcx,xsize  &
          ,zsize,rotation
!---------------------------------------------------------------------------
integer                   :: isimend,ienddays
integer, dimension(maxem) :: irelstrt,istrtdays,ireldur,idurdays,numparts
real, dimension(maxem)    :: emission,rparts,ratio
common/em/irelstrt,istrtdays,ireldur,idurdays,isimend,ienddays,emission  &
         ,numparts,rparts,ratio
!---------------------------------------------------------------------------
integer                   :: ieuler,ilagran,npart,nent  &
                            ,nrelpart,ncluster,ieavgcall,ilavgcall
integer, dimension(maxem) :: pspecies
real                      :: hytimemax,hytime,start_time
real, dimension(maxent)   :: anorm
real, dimension(maxem)    :: relstrt,relend,scale,relrate
common/hyp/ieuler,ilagran,npart,hytimemax,hytime,nrelpart,ncluster  &
          ,anorm,nent,start_time,relstrt,relend,scale,relrate  &
          ,pspecies,ilavgcall,ieavgcall
!---------------------------------------------------------------------------
integer, dimension(maxem)          :: npolypts
real, dimension(polypts,maxem)     :: rpartsp,ratiop,emissionp,scalep
real, dimension(6*polypts+2,maxem) :: xy
common/poly/npolypts,xy,rpartsp,ratiop,emissionp,scalep
!---------------------------------------------------------------------------
integer, dimension(nscratch)     :: iescr
integer, dimension(maxspec,maxg) :: ispec,ispeceavg,ispeclavg,ispecl,ispeclp
integer, dimension(maxg,maxspec) :: mspec,mspeceavg,mspeclavg,mspecl,mspeclp
common/euler/ispec,iescr,ispeceavg,ispeclavg,ispecl,ispeclp,mspec  &
            ,mspeceavg,mspeclavg,mspecl,mspeclp
!---------------------------------------------------------------------------
integer, dimension(maxspec,maxg) :: ibsxh,ibsyh,ibszh
common/memnest/ibsxh,ibsyh,ibszh
!---------------------------------------------------------------------------
integer :: maxxp,maxyp,maxzp
common/maxpts/maxxp,maxyp,maxzp
!---------------------------------------------------------------------------
