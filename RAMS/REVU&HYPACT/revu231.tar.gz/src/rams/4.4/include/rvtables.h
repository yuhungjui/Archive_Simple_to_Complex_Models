!
! Copyright (C) 1991-2003  ; All Rights Reserved ; Colorado State University
! Colorado State University Research Foundation ; ATMET, LLC
! 
! This file is free software; you can redistribute it and/or modify it under the
! terms of the GNU General Public License as published by the Free Software 
! Foundation; either version 2 of the License, or (at your option) any later version.
! 
! This software is distributed in the hope that it will be useful, but WITHOUT ANY 
! WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
! PARTICULAR PURPOSE.  See the GNU General Public License for more details.
!
! You should have received a copy of the GNU General Public License along with this 
! program; if not, write to the Free Software Foundation, Inc., 
! 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
!======================================================================================
!f90
!############################# Change Log ##################################
! 4.3.0.0
!
!###########################################################################

!---------------------------------------------------------------------------
!      i/o table commons and information

!---------------------------------------------------------------------------
integer, parameter :: maxvar=104+maxsclr  &
                     ,max3dv=86+maxsclr  &
                     ,max2dv=104  &
                     ,max4ds=8  &
                     ,max3dm=41+maxsclr

!---------------------------------------------------------------------------
integer, dimension(maxgrds)        :: nv3d,nv2d,nv3ds,nv3dm  &
                                     ,nh3d,nh2d,nh3ds,nh3dm  &
                                     ,na3d,na2d,na3ds,na3dm  &
                                     ,nsclr
integer, dimension(maxvar,maxgrds) :: ivtab3d,ivtab2d,ivtab3ds,ivtab3dm  &
                                     ,ihtab3d,ihtab2d,ihtab3ds,ihtab3dm  &
                                     ,iatab3d,iatab2d,iatab3ds,iatab3dm  &
                                     ,isclrp,isclrt
integer, dimension(maxvar)         :: ivtab3m
integer                            :: nv3dmt
! add new tables for the "mean" analysis files
integer, dimension(maxgrds)        :: nm3d,nm2d,nm3ds
integer, dimension(maxvar,maxgrds) :: imtab3d,imtab2d,imtab3ds
! add new tables for the "lite" analysis files
integer, dimension(maxgrds)        :: nl3d,nl2d,nl3ds
integer, dimension(maxvar,maxgrds) :: iltab3d,iltab2d,iltab3ds
! add new tables for both "mean" and "lite" analysis files
integer, dimension(maxgrds)        :: nb3d,nb2d,nb3ds
integer, dimension(maxvar,maxgrds) :: ibtab3d,ibtab2d,ibtab3ds
! add these for cross-referencing the "mean" variables
integer, dimension(maxvar,maxgrds) :: imxrf3d,imxrf2d,imxrf3ds
! add these for cross-referencing both "mean" and "lite" variables
integer, dimension(maxvar,maxgrds) :: ibxrf3d,ibxrf2d,ibxrf3ds
common /vtabls/ nv3d,nv2d,nv3ds,nv3dm  &
               ,nh3d,nh2d,nh3ds,nh3dm  &
               ,na3d,na2d,na3ds,na3dm  &
               ,ivtab3d,ivtab2d,ivtab3ds,ivtab3dm  &
               ,ihtab3d,ihtab2d,ihtab3ds,ihtab3dm  &
               ,iatab3d,iatab2d,iatab3ds,iatab3dm  &
               ,nsclr,isclrp,isclrt  &
               ,ivtab3m,nv3dmt  &
               ,nm3d,nm2d,nm3ds  &
               ,imtab3d,imtab2d,imtab3ds  &
               ,nl3d,nl2d,nl3ds  &
               ,iltab3d,iltab2d,iltab3ds  &
               ,nb3d,nb2d,nb3ds  &
               ,ibtab3d,ibtab2d,ibtab3ds  &
               ,imxrf3d,imxrf2d,imxrf3ds  &
               ,ibxrf3d,ibxrf2d,ibxrf3ds

!---------------------------------------------------------------------------
integer, dimension(maxgrds)        :: marker3n  &
                                     ,iupn     ,iucn     ,ivpn  &
                                     ,ivcn     ,iwpn     ,iwcn  &
                                     ,ippn     ,ipcn     ,ithpn  &
                                     ,irtpn    ,ircpn    ,irrpn  &
                                     ,irppn    ,irspn    ,irapn  &
                                     ,irgpn    ,irhpn    ,iccpn  &
                                     ,icrpn    ,icppn    ,icspn  &
                                     ,icapn    ,icgpn    ,ichpn  &
                                     ,icccnpn  ,icifnpn  ,ihkmn  &
                                     ,iq2n     ,iq6n     ,iq7n   &
                                     ,irvn     ,ithetan  ,itkepn   &
                                     ,itklpn   ,ithsrcn  ,irtsrcn  &
                                     ,ifthrdn  ,ivarupn  ,ivarvpn  &
                                     ,ivartpn  ,ivarrpn  ,ivarufn  &
                                     ,ivarvfn  ,ivartfn  ,ivarrfn  &
                                     ,ivarwtsn ,ipi0n    ,idn0n  &
                                     ,ith0n    ,ivkmn    ,ivkhn  &
                                     ,idn0un   ,idn0vn  &
                                     ! add the averaged 3d variables
                                     ! starting at index 54 --> 86
                                     ,iupmn    ,ivpmn    ,iwpmn  &
                                     ,ippmn    ,ircpmn   ,irrpmn  &
                                     ,irppmn   ,irspmn   ,irapmn  &
                                     ,irgpmn   ,irhpmn   ,iccpmn  &
                                     ,icrpmn   ,icppmn   ,icspmn  &
                                     ,icapmn   ,icgpmn   ,ichpmn  &
                                     ,icccnpmn ,icifnpmn ,ihkmmn  &
                                     ,iq2mn    ,iq6mn    ,iq7mn  &
                                     ,irvmn    ,ithetamn ,itkepmn  &
                                     ,itklpmn  ,ithsrcmn ,irtsrcmn &
                                     ,ifthrdmn ,ivkmmn   ,ivkhmn
integer,dimension(maxgrds,maxsclr) :: isclpn

! would normally add isclpm(maxsclr) here, but don't have an index
! to assign in vtable, so lets not allow averaging of added scalars

common /index3n/ marker3n  &
                ,iupn     ,iucn     ,ivpn  &
                ,ivcn     ,iwpn     ,iwcn  &
                ,ippn     ,ipcn     ,ithpn  &
                ,irtpn    ,ircpn    ,irrpn  &
                ,irppn    ,irspn    ,irapn  &
                ,irgpn    ,irhpn    ,iccpn  &
                ,icrpn    ,icppn    ,icspn  &
                ,icapn    ,icgpn    ,ichpn  &
                ,icccnpn  ,icifnpn  ,ihkmn  &
                ,iq2n     ,iq6n     ,iq7n   &
                ,irvn     ,ithetan  ,itkepn   &
                ,itklpn   ,ithsrcn  ,irtsrcn  &
                ,ifthrdn  ,ivarupn  ,ivarvpn  &
                ,ivartpn  ,ivarrpn  ,ivarufn  &
                ,ivarvfn  ,ivartfn  ,ivarrfn  &
                ,ivarwtsn ,ipi0n    ,idn0n  &
                ,ith0n    ,ivkmn    ,ivkhn  &
                ,idn0un   ,idn0vn  &
                ,iupmn    ,ivpmn    ,iwpmn  &
                ,ippmn    ,ircpmn   ,irrpmn  &
                ,irppmn   ,irspmn   ,irapmn  &
                ,irgpmn   ,irhpmn   ,iccpmn  &
                ,icrpmn   ,icppmn   ,icspmn  &
                ,icapmn   ,icgpmn   ,ichpmn  &
                ,icccnpmn ,icifnpmn ,ihkmmn  &
                ,iq2mn    ,iq6mn    ,iq7mn  &
                ,irvmn    ,ithetamn ,itkepmn  &
                ,itklpmn  ,ithsrcmn ,irtsrcmn &
                ,ifthrdmn ,ivkmmn   ,ivkhmn  &
                ,isclpn

!---------------------------------------------------------------------------
integer, dimension(maxgrds) :: marker2n  &
                              ,itoptn    ,itopun    ,itopvn  &
                              ,itopmn    ,irtgtn    ,irtgun  &
                              ,irtgvn    ,irtgmn    ,if13tn  &
                              ,if13un    ,if13vn    ,if13mn  &
                              ,if23tn    ,if23un    ,if23vn  &
                              ,if23mn    ,idxun     ,idxvn  &
                              ,idxtn     ,idxmn     ,idyun  &
                              ,idyvn     ,idytn     ,idymn  &
                              ,ifmapun   ,ifmapvn   ,ifmaptn  &
                              ,ifmapmn   ,ifmapuin  ,ifmapvin  &
                              ,ifmaptin  ,ifmapmin  ,iglatn  &
                              ,iglonn    ,iuwn      ,ivwn  &
                              ,iwfzn     ,itfzn     ,iqfzn  &
                              ,iaccprn   ,iaccppn   ,iaccpsn  &
                              ,iaccpan   ,iaccpgn   ,iaccphn  &
                              ,ipcprrn   ,ipcprpn   ,ipcprsn  &
                              ,ipcpran   ,ipcprgn   ,ipcprhn  &
                              ,ipcpgn    ,iqpcpgn   ,idpcpgn  &
                              ,iaconprn  ,iconprrn  ,irshortn  &
                              ,irlongn   ,irlongupn ,ialbedtn  &
                              ,ivarpn    ,ivarp2n   ,ifcorun  &
                              ,ifcorvn   ,ivt2dan   ,ivt2dbn  &
                              ,ivt2dcn   ,ivt2ddn   ,ivt2den  &
                              ,ivt2dfn   ,icoszn    ,itopzon  &
                              ! add the averaged 2d variables 
                              ! starting at index 73 --> 103
                              ,itoptmn    ,iglatmn   ,iglonmn  &
                              ,iuwmn      ,ivwmn     ,iwfzmn  &
                              ,itfzmn     ,iqfzmn    ,iaccprmn  &
                              ,iaccppmn   ,iaccpsmn  ,iaccpamn  &
                              ,iaccpgmn   ,iaccphmn  ,ipcprrmn  &
                              ,ipcprpmn   ,ipcprsmn  ,ipcpramn  &
                              ,ipcprgmn   ,ipcprhmn  ,ipcpgmn  &
                              ,iqpcpgmn   ,idpcpgmn  ,iaconprmn  &
                              ,iconprrmn  ,irshortmn ,irlongmn  &
                              ,irlongupmn ,ialbedtmn ,icoszmn  &
                              ,itopzomn   ,icputimen
common /index2n/ marker2n  &
                ,itoptn    ,itopun    ,itopvn  &
                ,itopmn    ,irtgtn    ,irtgun  &
                ,irtgvn    ,irtgmn    ,if13tn  &
                ,if13un    ,if13vn    ,if13mn  &
                ,if23tn    ,if23un    ,if23vn  &
                ,if23mn    ,idxun     ,idxvn   &
                ,idxtn     ,idxmn     ,idyun  &
                ,idyvn     ,idytn     ,idymn  &
                ,ifmapun   ,ifmapvn   ,ifmaptn  &
                ,ifmapmn   ,ifmapuin  ,ifmapvin  &
                ,ifmaptin  ,ifmapmin  ,iglatn  &
                ,iglonn    ,iuwn      ,ivwn  &
                ,iwfzn     ,itfzn     ,iqfzn  &
                ,iaccprn   ,iaccppn   ,iaccpsn  &
                ,iaccpan   ,iaccpgn   ,iaccphn  &
                ,ipcprrn   ,ipcprpn   ,ipcprsn  &
                ,ipcpran   ,ipcprgn   ,ipcprhn  &
                ,ipcpgn    ,iqpcpgn   ,idpcpgn  &
                ,iaconprn  ,iconprrn  ,irshortn  &
                ,irlongn   ,irlongupn ,ialbedtn  &
                ,ivarpn    ,ivarp2n   ,ifcorun  &
                ,ifcorvn   ,ivt2dan   ,ivt2dbn  &
                ,ivt2dcn   ,ivt2ddn   ,ivt2den  &
                ,ivt2dfn   ,icoszn    ,itopzon  &
                ,itoptmn    ,iglatmn   ,iglonmn  &
                ,iuwmn      ,ivwmn     ,iwfzmn  &
                ,itfzmn     ,iqfzmn    ,iaccprmn  &
                ,iaccppmn   ,iaccpsmn  ,iaccpamn  &
                ,iaccpgmn   ,iaccphmn  ,ipcprrmn  &
                ,ipcprpmn   ,ipcprsmn  ,ipcpramn  &
                ,ipcprgmn   ,ipcprhmn  ,ipcpgmn  &
                ,iqpcpgmn   ,idpcpgmn  ,iaconprmn  &
                ,iconprrmn  ,irshortmn ,irlongmn  &
                ,irlongupmn ,ialbedtmn ,icoszmn  &
                ,itopzomn   ,icputimen

!---------------------------------------------------------------------------
integer, dimension(maxgrds) :: marker4sn  &
                              ,itgpn  ,iwgpn  ,ischarn  ,igsfn  &
                              ! add the averaged 3d soil variables 
                              ! starting at index 5 --> 8
                              ,itgpmn ,iwgpmn ,ischarmn ,igsfmn
common/index4sn/ marker4sn  &
                ,itgpn  ,iwgpn  ,ischarn  ,igsfn  &
                ,itgpmn ,iwgpmn ,ischarmn ,igsfmn

!---------------------------------------------------------------------------
integer, dimension(maxgrds,0:max3dv) :: ind3dn
integer, dimension(maxgrds,0:max2dv) :: ind2dn
integer, dimension(maxgrds,0:max4ds) :: ind3dsn
equivalence (ind3dn,marker3n),(ind2dn,marker2n),(ind3dsn,marker4sn)
integer, dimension(0:max3dv)         :: ind3d
integer, dimension(0:max2dv)         :: ind2d
integer, dimension(0:max4ds)         :: ind3ds
integer, dimension(0:max3dm)         :: ind3dm
equivalence (ind3d,marker3),(ind2d,marker2),(ind3ds,marker4s) &
           ,(ind3dm,marker3m)

!---------------------------------------------------------------------------
integer, dimension(maxgrds)        :: nmp31,nmp32,nmp33,nmp3i  &
                                     ,nmp21,nmp22,nmp23,nmp2i  &
                                     ,nmps1,nmps2,nmps3,nmpsi
integer, dimension(maxvar,maxgrds) :: mp3tab1,mp3tab2,mp3tab3,mp3tabi  &
                                     ,mp2tab1,mp2tab2,mp2tab3,mp2tabi  &
                                     ,mpstab1,mpstab2,mpstab3,mpstabi
common /mpvtable/ nmp31,mp3tab1,nmp32,mp3tab2  &
                 ,nmp33,mp3tab3,nmp3i,mp3tabi  &
                 ,nmp21,mp2tab1,nmp22,mp2tab2  &
                 ,nmp23,mp2tab3,nmp2i,mp2tabi  &
                 ,nmps1,mpstab1,nmps2,mpstab2  &
                 ,nmps3,mpstab3,nmpsi,mpstabi

!---------------------------------------------------------------------------
character(len=8), dimension(maxvar,maxgrds) :: ivopt3d,ivopt2d,ivopt3ds  &
                                              ,ivopt3dm
character(len=8), dimension(maxvar)         :: ivopt3m
common /vtabopt/ ivopt3d,ivopt2d,ivopt3ds,ivopt3dm,ivopt3m

!---------------------------------------------------------------------------
character(len=8), dimension(maxvar,maxgrds) :: &
                mp3chr1,mp3chr2,mp3chr3,mp3chri  &
               ,mp2chr1,mp2chr2,mp2chr3,mp2chri  &
               ,mpschr1,mpschr2,mpschr3,mpschri  &
               ,ivchr3d,ivchr2d,ivchr3ds,ivchr3dm  &
               ,ihchr3d ,ihchr2d,ihchr3ds,ihchr3dm  &
               ,iachr3d ,iachr2d,iachr3ds,iachr3dm  &
               ,ischrp,ischrc,ischrt  &
               ! add new tables for the "mean" analysis files
               ,imchr3d,imchr2d,imchr3ds  &
               ! add new tables for the "lite" analysis files
               ,ilchr3d,ilchr2d,ilchr3ds  &
               ! add new tables for both "mean" and "lite" analysis files
               ,ibchr3d,ibchr2d,ibchr3ds
common /vtabch/ mp3chr1,mp3chr2,mp3chr3,mp3chri  &
               ,mp2chr1,mp2chr2,mp2chr3,mp2chri  &
               ,mpschr1,mpschr2,mpschr3,mpschri  &
               ,ivchr3d,ivchr2d,ivchr3ds,ivchr3dm  &
               ,ihchr3d,ihchr2d,ihchr3ds,ihchr3dm  &
               ,iachr3d,iachr2d,iachr3ds,iachr3dm  &
               ,ischrp,ischrc,ischrt  &
               ,imchr3d,imchr2d,imchr3ds  &
               ,ilchr3d,ilchr2d,ilchr3ds  &
               ,ibchr3d,ibchr2d,ibchr3ds

!---------------------------------------------------------------------------
integer                            :: membsz
integer, dimension(maxgrds)        :: ibux,ibuy,ibuz,ibvx,ibvy,ibvz  &
                                     ,ibwx,ibwy,ibwz,ibpx,ibpy,ibpz
integer, dimension(maxvar,maxgrds) :: ibsx,ibsy,ibsz
common /nbndind/ membsz  &
                ,ibux,ibuy,ibuz,ibvx,ibvy,ibvz  &
                ,ibwx,ibwy,ibwz,ibpx,ibpy,ibpz  &
                ,ibsx,ibsy,ibsz

!---------------------------------------------------------------------------
