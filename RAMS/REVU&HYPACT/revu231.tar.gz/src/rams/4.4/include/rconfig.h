!
! Copyright (C) 1991-2003  ; All Rights Reserved ; Colorado State University
! Colorado State University Research Foundation ; ATMET, LLC
! 
! This file is free software; you can redistribute it and/or modify it under the
! terms of the GNU General Public License as published by the Free Software 
! Foundation; either version 2 of the License, or (at your option) any later version.
! 
! This software is distributed in the hope that it will be useful, but WITHOUT ANY 
! WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
! PARTICULAR PURPOSE.  See the GNU General Public License for more details.
!
! You should have received a copy of the GNU General Public License along with this 
! program; if not, write to the Free Software Foundation, Inc., 
! 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
!======================================================================================
!f90
!############################# Change Log ##################################
! 4.3.0.0
!
!###########################################################################

!---------------------------------------------------------------------------
!  Set maximum values of parameters:

integer, parameter :: MAXGRDS=8     ! MAXGRDS - Maximum number of grids

integer, parameter :: NXPMAX=303    ! NXPMAX  - Maximum number of points 
                                    !             in x-direction
integer, parameter :: NYPMAX=303    ! NYPMAX  - Maximum number of points 
                                    !             in y-direction
integer, parameter :: NZPMAX=132    ! NZPMAX  - Maximum number of points 
                                    !             in z-direction
integer, parameter :: NZGMAX=20     ! NZGMAX  - Maximum number of soil levels

integer, parameter :: MAXSCLR=150   ! MAXSCLR - Maximum number of additional 
                                    !             scalars
integer, parameter :: MAXHP=1000    ! MAXHP   - Maximum number of u, v, OR t 
                                    !             points in a single vertical
                                    !             level interpolated from 
                                    !             opposite hemispheric grid
                                    
!---------------------------------------------------------------------------
!  Set MAXDIM to the largest of NXPMAX,NYPMAX,NZPMAX+10,NZGMAX

integer, parameter :: MAXDIM=303

!---------------------------------------------------------------------------
!  maxmach is the max number of processors that can be used in a parallel run

integer, parameter :: maxmach=64
